#pragma once

#include <QWidget>
using namespace std;
#include <QtWidgets/QDialog>
namespace Mayo {

class PathGeneration : public QDialog {
	Q_OBJECT
public:
	PathGeneration(QWidget* parent = nullptr);
	~PathGeneration();

private slots:
	void callBack();
	void on_btnOpenTrajFile_clicked();

	void on_btnSave_clicked();

	//void on_btnOpenCoordFile_clicked();

	//void on_btnSaveTraj_clicked();

	void on_btnOpenCoord_clicked();

	void on_btnConvert_clicked();
private:
	void parseCsvData(string dataPath);
	void parseFunacData(string dataPath);
	void parseGugaoData(string dataPath);
	class Ui_PathGeneration* m_ui = nullptr;
};

} // namespace Mayo