﻿
#include "PathGeneration.h"
#include "ui_PathGeneration.h"
#include "src/dataParser/csvDataParser.h"
#include "src/dataParser/funacDataParser.h"
#include "src/dataParser/gugaoDataParser.h"
#include "src/dataSaver/gugaoDataWriter.h"
#include "src/lib/pathConvert.h"
#include <QFileDialog>
#include <QMessageBox>
#include <QTextCodec>
//#include "moc_MyH.cpp"
using namespace std;


vector<GP1Data> mGP1Coord;
vector<GP2Data> mGP2Coord;
GugaoHeader mGugaoHeaderCoord;

vector<GP1Data> mGP1Path;
vector<GP2Data> mGP2Path;
GugaoHeader mGugaoHeaderPath;

PathConvert mPathConvert;

namespace Mayo {

    PathGeneration::PathGeneration(QWidget* parent)
        : QDialog(parent),
        m_ui(new Ui_PathGeneration)
    {
        m_ui->setupUi(this);
        //m_ui->label->setText(
        //    tr("%1 By %2").arg(QApplication::applicationName(),
        //        QApplication::organizationName()));
        //connect(m_ui->pushButton, SIGNAL(clicked()), this, SLOT(callBack()));
        //m_ui->label->setPixmap(QPixmap("images/operationPanel.png"));
    }
    PathGeneration::~PathGeneration(){
        delete m_ui;
    }
    void PathGeneration::callBack() {
        this->close();
    }

    void PathGeneration::on_btnOpenTrajFile_clicked()
    {
        if (m_ui->radBtnGugao->isChecked())
        {
            QString fileName = QFileDialog::getOpenFileName(this, tr("Open Path"), "/C:/Users/user/Desktop/", tr("Files(*.prg)"));
            m_ui->labelStatus->setText(fileName);

            //string fileName = "/home/lzhx180/QtDev/pathConvertor/data/A-Wt1-RY.prg";//fileName.toStdString();
            GugaoDataParser gugaoParser;
            gugaoParser.parseData(fileName.toStdString());
            mGP1Path = gugaoParser.mGP1;
            mGP2Path = gugaoParser.mGP2;
            mGugaoHeaderPath = gugaoParser.mGugaoHeader;
            //ui->lShowPosX->setText(QString::fromStdString(to_string(gugaoParser.mGugaoHeader.vAcc[0])));
        }
        else
        {
        
            QMessageBox::information(this, "Warning!", "PLease select GuGao format!", QMessageBox::Ok);
        }
    }

    void PathGeneration::on_btnOpenCoord_clicked()
    {
        if (m_ui->radBtnGugao->isChecked() || m_ui->radBtnCSV->isChecked() || m_ui->radBtnFunac->isChecked())
        {
            //QString fileName = QFileDialog::getOpenFileName(this,tr("打开坐标"),"/home/",tr("Files(*.csv *.txt *prg *.ls)"));
            //ui->labelStatus->setText(fileName);
            //string fileName = "/home/lzhx180/QtDev/pathConvertor/data/CalibrationPoints.prg";//fileName.toStdString();

            QString fileName = QFileDialog::getOpenFileName(this, tr("Open Path"), "/C:/Users/user/Desktop/", tr("Files(*.prg)"));

            if (m_ui->radBtnCSV->isChecked())
            {
                // Parse csv data
                CsvDataParser pData;
                Document docData(fileName.toStdString());
                pData.parseTargetPos(docData);
                mGP1Coord = pData.mGP1;
                mGP2Coord = pData.mGP2;
                //parseCsvData(fileName.toStdString());
            }
            if (m_ui->radBtnFunac->isChecked())
            {
                // Parse funac data
                FunacDataParser funacParser;
                funacParser.parseData(fileName.toStdString(), "../pathConvertor/data/output.txt");
                mGP1Coord = funacParser.mGP1;
                mGP2Coord = funacParser.mGP2;
                //parseFunacData(fileName.toStdString());
            }
            if (m_ui->radBtnGugao->isChecked())
            {
                GugaoDataParser gugaoParser;
                gugaoParser.parseData(fileName.toStdString());
                mGP1Coord = gugaoParser.mGP1;
                mGP2Coord = gugaoParser.mGP2;
                mGugaoHeaderCoord = gugaoParser.mGugaoHeader;

                // ui->lShowPosX->setText(QString::fromStdString(to_string(gugaoParser.mGugaoHeader.vAcc[0])));

                // PathConvert pathConvert;
                 //pathConvert.pathExtract(gugaoParser.mGP1, gugaoParser.mGP2);

           //      pathConvert.convert();

                 //parseGugaoData(sFileName);
            }
        }
        else
        {
            QMessageBox::information(this, "Warning!", "PLease select GuGao/Funac/csv format!", QMessageBox::Ok);
        }
    }

    void PathGeneration::on_btnConvert_clicked()
    {
        // Converting
        //QMessageBox::information(this,"轨迹转换","轨迹成功转换至csv！",QMessageBox::Ok);
        if (m_ui->radBtnGugao->isChecked())
        {
            mPathConvert.pathExtract(mGP1Path, mGP2Path);
            mPathConvert.convert(mGP1Coord, mGP2Coord);

            QMessageBox::information(this, "Trajectory Transformation", "Trajectory transformed successfully！", QMessageBox::Ok);
        }
        else
        {
            QMessageBox::information(this, "Warning！", "Please open trajectory and coordinate of Gugao file format!", QMessageBox::Ok);
        }
    }

    void PathGeneration::on_btnSave_clicked()
    {
        //QMessageBox::information(this,"Message","You Clicked Button!",QMessageBox::Ok);  
        QString fileName = QFileDialog::getSaveFileName(this, tr("Save Path"), "/C:/Users/user/Desktop", tr("Files(*.prg)"));
        m_ui->labelStatus->setText(fileName);

        if (!mGP1Coord.empty() && !mGP2Coord.empty())
        {
            // Save Gugao data
            GugaoDataWriter dataWriter;
            //dataWriter.saveTrajectory(dataHomePath + "plannedPath.prg", mGugaoHeaderPath, mPathConvert.mGp1NewPath, mPathConvert.mGp2NewPath);
            dataWriter.saveTrajectory(fileName.toStdString(), mGugaoHeaderPath, mPathConvert.mGp1NewPath, mPathConvert.mGp2NewPath);

            QMessageBox::information(this, "Save the trajectory", "The trajectory has been saved！", QMessageBox::Ok);
        }
    }




    void PathGeneration::parseCsvData(string dataPath)
    {
        // Parse csv data
        CsvDataParser pData;
        Document docData(dataPath);
        pData.parseTargetPos(docData);

        // Show csv data on UI
        //string str = to_string(pData.mPose[0].OriX);
    }

    void PathGeneration::parseFunacData(string dataPath)
    {
        // Parse funac data
        FunacDataParser funacParser;
        funacParser.parseData(dataPath, "../pathConvertor/data/output.txt");
    }
    void PathGeneration::parseGugaoData(string dataPath)
    {
        // Parse funac data
        GugaoDataParser gugaoParser;
        gugaoParser.parseData(dataPath);
    }

    void saveData()
    {
        string dataHomePath = "../pathConvertor/data/";

        // Parse csv data
        CsvDataParser pData;
        Document docData(dataHomePath + "input.csv");
        pData.parseTargetPos(docData);

        // Show csv data on UI
        //string str = to_string(pData.mPose[0].OriX);
        //ui->lShowPosX->setText(QVariant(pData.mPose[0].PosX).toString());

        // Parse funac data
        FunacDataParser funacParser;
        funacParser.parseData(dataHomePath + "data.ls", dataHomePath + "output.txt");

        // Temporary data creating for saving trajectory
        vector<vector<double>> tempPos(10, vector<double>(8, 1.001));
        vector<vector<double>> tempPlatform(10, vector<double>(8, 2.002));
        // Save Gugao data
        //GugaoDataWriter dataWriter;
        //dataWriter.saveTrajectory(dataHomePath + "plannedPath.prg", tempPos, tempPlatform);
    }

} // namespace May
