/*********************************************************************
* Write planned trajectory data to file
 *********************************************************************/
#include <iostream>
#include <math.h>
#include <cmath>
#include <fstream>
#include <string>
#include <sstream>
#include <typeinfo>
#include <algorithm>
#include <vector>

#ifndef DATATYPE_H
#define DATATYPE_H

#endif // DATATYPE_H

#ifndef M_PI
#define M_PI (3.14159265358979323846)
#endif

using namespace std;

const double PI  =3.141592653589793238463;
string sDefMsgHeader = "SPEED SP=30%\nDYN ACC=20 DEC=20 J=250\n";
string sDefDataHeader = "MOVJ V=20% BL=0.00 VBL=0.00 @2,1,0,1,";

class GugaoDataWriter
{
	private:
	struct OverAngleLimit
	{
		vector<int> overLimitJoint;
		vector<int> overLimitPoint;
		vector<double> overLimitValue;
	};  

public:
bool saveTrajectory(string filename, GugaoHeader mGugaoHeader, vector<GP1Data> vPos, vector<GP2Data> platformPose)
{
  ofstream outfile(filename);

  // Create the header of the saved file
  outfile << "NOP" << endl;
  if (mGugaoHeader.vsSpeedHeader.empty())
  {
    outfile << sDefMsgHeader;
  }
  else
  {
    outfile << mGugaoHeader.vsSpeedHeader[0] <<endl;
    outfile << "DYN ACC=" << mGugaoHeader.vAcc[0] << " DEC=" << mGugaoHeader.vDec[0] << " J=" << mGugaoHeader.vJ[0] << endl;
  }

  for(int i = 0; i < static_cast<int>(vPos.size()); ++i)
  {
    if (mGugaoHeader.vsDataHeader.empty())
    {
      outfile << sDefDataHeader;
    }
    else
    {
      outfile << mGugaoHeader.vsDataHeader[i];
    }
    outfile << createPosMatrix(vPos[i]);
    outfile << createDummyPosMatrix(8);
    outfile << "$";
    //outfile << createPosToExternal(vPos[i]);
    outfile << createRotationMatrix(platformPose[i]);
  }
  outfile << "END" << endl;
  outfile.close();

  return true;
}

	// create the matrix includes positions (in deg) of all joints in the trajectory's history
	private:
  string createPosMatrix(GP1Data gp1)
	{
    string sPos;
    sPos = sPos + to_string(gp1.X) + ",";
    sPos = sPos + to_string(gp1.Y) + ",";
    sPos = sPos + to_string(gp1.Z) + ",";
    sPos = sPos + to_string(gp1.W) + ",";
    sPos = sPos + to_string(gp1.P) + ",";
    sPos = sPos + to_string(gp1.R) + ",";
    sPos = sPos + to_string(0) + "," + to_string( 0 );
		
		return sPos;
	}
	
	private:
	string createPosToExternal(vector<double> dJ)
	{
    //int vecSize = dJ.size();
		string sPos;//= "P[" + to_string(nNum) + "]{ \n";		
		
		for(int i = 0; i < 1; ++i)
		{
			sPos = sPos + to_string( dJ[i]*1000 );

			//if(i < 1)
			//{
			    sPos = sPos + ",";
			//}
		}		
		return sPos;
	}
	
	
	private:
	string createDummyPosMatrix(int vecSize)
	{
		string sPos = "$";
		sPos = sPos + "0,0,0,0,";
				
		for(int i = 0; i < vecSize; ++i)
		{
			sPos = sPos + to_string(0);
			
			if(i < (vecSize -1))
			{
			    sPos = sPos + ",";
			}
		}
		//sPos +=  "\n";
		
		return sPos;
	}

	private:
  string createRotationMatrix(GP2Data gp2)
	{
		string sPos;
		int vecSize = 6;

    sPos = sPos + to_string(gp2.J1) + ",";
    sPos = sPos + to_string(gp2.J2) + ",";
		
		for (int i = 0; i<vecSize; i++)
		{
			sPos = sPos + to_string( 0 );
			
			if(i < (vecSize-1))
			{
			    sPos = sPos + ",";
			}
		}
		sPos +=  "\n";
		
		return sPos;
	}	
	

public:
bool writeFile(string filename, vector<int> vals)
{
  ofstream outfile(filename);

  outfile << "Saved data as follows: " << endl;

  // Send data to the stream
  for(int i = 0; i < vals.size(); ++i)
  {
    outfile << vals.at(i) << endl;
  }

  outfile.close();

  return true;
}

public:
bool angleLimitCheck(string filename, vector<vector<double>> vals, double threshold)
{
  ofstream outfile(filename);

  // Save the joint number, point number and the value that violates the threshold
  OverAngleLimit angleLimit = limitDetector(vals, threshold);
  int size = angleLimit.overLimitPoint.size();
  if (size < 1)
  {
    return false;
  }

  outfile << endl << "Threshold violation detected! \n";
  outfile << endl << "Number of points violated limit: " + to_string(size) << endl;

  for (int i = 0; i < size; ++i)
  {
    outfile << "P[" + to_string(angleLimit.overLimitPoint[i] + 1) + "] -- "
    << "J[" + to_string(angleLimit.overLimitJoint[i]) + "] -- "
    << "Value = " + to_string(angleLimit.overLimitValue[i]) << endl;
  }

  return true;
}
	
	// create the matrix includes velocities of all joints in the trajectory's history
	private:
	string createVelMatrix(int nNum, vector<double> dJ)
	{
		string sPos = "V[" + to_string(nNum) + "]{ \n";
		for(int i = 0; i < dJ.size(); ++i)
		{
			sPos = sPos + "J" + to_string(i+1) + " = " + to_string( radToDeg(dJ[i]) ) + " deg/s,";
		}
		sPos +=  "\n };\n";
		
		return sPos;
	}
	
	// create the matrix includes accelerations of all joints in the trajectory's history
	private:
	string createAccMatrix(int nNum, vector<double> dJ)
	{
		string sPos = "A[" + to_string(nNum) + "]{ \n";
		for(int i = 0; i < dJ.size(); ++i)
		{
			sPos = sPos + "J" + to_string(i+1) + " = " + to_string( radToDeg(dJ[i]) ) + " deg/s2,";
		}
		sPos +=  "\n };\n";
		
		return sPos;
	}
	
	private:
	double radToDeg(double rad)
	{
		return rad*180/PI;
	}

	private:
  OverAngleLimit limitDetector(vector<vector<double>> points, double threshold)
	{
		OverAngleLimit overLimit;		
    vector<double> prePos = points[0];
		int pointSize = points.size();
		
		if (pointSize < 2)
		{
			return overLimit; // not to proceed if the trajectory points are less than 2
		}
		
		for (int i = 1; i < pointSize; ++i)
		{
      for(int j =0; j < static_cast<int>(points[i].size()); ++j)
			{
        double residual = abs(points[i][j] - prePos[j]);
				if ( residual > threshold)
				{
					overLimit.overLimitPoint.push_back(i);
					overLimit.overLimitJoint.push_back(j);
					overLimit.overLimitValue.push_back(residual);
				}
			}			
		}
		
		return overLimit;
	}
	
};
