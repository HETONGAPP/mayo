#include <iostream>
#include <math.h>
#include <cmath>
#include <fstream>
#include <string>
#include <sstream>
#include <typeinfo>
#include <algorithm>
#include <vector>

#ifndef DATATYPE_H
#include "src/lib/dataType.h"
#endif // DATATYPE_H

#ifndef M_PI
#define M_PI (3.14159265358979323846)
#endif

using namespace std;

class FunacDataParser
{	
	public:
	vector<GP1Data> mGP1;
	vector<GP2Data> mGP2;
	
  public:
	void parseData (string filename, string output_filename)
	{
	    vector<double> input_x;
	    vector<double> input_y;
	    vector<double> input_z;
	    vector<double> input_w;
	    vector<double> input_p;
	    vector<double> input_r;
	    vector<double> input_j1;
	    vector<double> input_j2;
	    vector<int> pos_xyz_end;
	    vector<int> pos_wp_end;
	    vector<int> pos_j;
	    int line=0;
	    int row=0;
	    int pos_x_begin=0;
	    int pos_y_begin=0;
	    int pos_z_begin=0;
	    int pos_x_end=0;
	    int pos_y_end=0;
	    int pos_z_end=0;
	    int pos_w_begin=0;
	    int pos_p_begin=0;
	    int pos_r_begin=0;
	    int pos_w_end=0;
	    int pos_p_end=0;
	    int pos_r_end=0;
	    int pos_j1_begin=0;
	    int pos_j2_begin=0;
	    int pos_j1_end=0;
	    int pos_j2_end=0;
	    int x_len=0;
	    int y_len=0;
	    int z_len=0;
	    int w_len=0;
	    int p_len=0;
	    int r_len=0;
	    int j1_len=0;
	    int j2_len=0;
	    int pos=0;
	    int wpr_pos=0;
	    int j1j2_pos=0;
	    int xyzwpr_begin_modify=4;
	    int j1j2_begin_modify=5;
	    int xyz_end_modify=3;
	    int wpj1_end_modify=4;
	    int rj2_end_modify=5;
      string STRING,word,overall;
	    ifstream infile;
	    infile.open(filename);
	    ofstream outfile(output_filename);
	    if (infile.is_open())
	    {
	      while(getline(infile,STRING))
	      {
	       ++line;
	       istringstream temp_str(STRING);
	       //cout<<STRING<<endl;
	       
	       //Read X,Y,Z
		if (STRING.compare(0,4,"\tX =")==0){
		   //pos_z_end=STRING.length()-xyz_end_modify;
       for (pos=0; pos < static_cast<int>(STRING.length());pos++)
		   { 
		     if (STRING[pos]==',')
		      {
		       pos_xyz_end.push_back(pos);
		      }
		     if (STRING[pos]=='X')
		     {
		      pos_x_begin=pos+xyzwpr_begin_modify;
		     }
		     
		     if (STRING[pos]=='Y')
		     {
		      pos_y_begin=pos+xyzwpr_begin_modify;
		     }
		     if (STRING[pos]=='Z')
		     {
		     pos_z_begin=pos+xyzwpr_begin_modify;
		   }              
		} 
		pos_x_end=pos_xyz_end[0]-xyz_end_modify;
		pos_y_end=pos_xyz_end[1]-xyz_end_modify;
		pos_z_end=pos_xyz_end[2]-xyz_end_modify;
		x_len=pos_x_end-pos_x_begin;
		input_x.push_back(stod(STRING.substr(pos_x_begin,x_len)));
		y_len=pos_y_end-pos_y_begin;
		input_y.push_back(stod(STRING.substr(pos_y_begin,y_len)));
		z_len=pos_z_end-pos_z_begin;
		input_z.push_back(stod(STRING.substr(pos_z_begin,z_len)));
	       } 

	     //Read W,P,R
		if (STRING.compare(0,4,"\tW =")==0){
		   pos_r_end=STRING.length()-rj2_end_modify;
		   for (wpr_pos=0; wpr_pos<STRING.length();wpr_pos++)
		   { 
		     if (STRING[wpr_pos]==',')
		      {
		       pos_wp_end.push_back(wpr_pos);
		      }
		      
		     if (STRING[wpr_pos]=='W')
		     {
		      pos_w_begin=wpr_pos+xyzwpr_begin_modify;
		     }
		     
		     if (STRING[wpr_pos]=='P')
		     {
		      pos_p_begin=wpr_pos+xyzwpr_begin_modify;
		     }
		     if (STRING[wpr_pos]=='R')
		     {
		     pos_r_begin=wpr_pos+xyzwpr_begin_modify;
		     }
		   } 
		   pos_w_end=pos_wp_end[0]-wpj1_end_modify;
		   pos_p_end=pos_wp_end[1]-wpj1_end_modify; 
		   w_len=pos_w_end-pos_w_begin;
		   input_w.push_back(stod(STRING.substr(pos_w_begin,w_len)));
		   p_len=pos_p_end-pos_p_begin;
		   input_p.push_back(stod(STRING.substr(pos_p_begin,p_len)));
		   r_len=pos_r_end-pos_r_begin;
		   input_r.push_back(stod(STRING.substr(pos_r_begin,r_len)));
		  }  
	       //Read J1 J2
		if (STRING.compare(0,5,"\tJ1 =")==0)
		{
		   pos_j2_end=STRING.length()-rj2_end_modify;
		   for (j1j2_pos=0; j1j2_pos<STRING.length();j1j2_pos++)
		   { 
		     if (STRING[j1j2_pos]==',')
		      {
		       pos_j1_end=j1j2_pos-wpj1_end_modify;
		      }
		      
		     if (STRING[j1j2_pos]=='J')
		     {
		      pos_j.push_back(j1j2_pos);
		     }
		   } 
		   pos_j1_begin=pos_j[0]+j1j2_begin_modify;
		   pos_j2_begin=pos_j[1]+j1j2_begin_modify;
		   j1_len=pos_j1_end-pos_j1_begin;
		   j2_len=pos_j2_end-pos_j2_begin;
		   input_j1.push_back(stod(STRING.substr(pos_j1_begin,j1_len)));
		   input_j2.push_back(stod(STRING.substr(pos_j2_begin,j2_len)));                       
		}
		  
	     pos_xyz_end.erase (pos_xyz_end.begin(),pos_xyz_end.end());
	     pos_wp_end.erase (pos_wp_end.begin(),pos_wp_end.end());
	     pos_j.erase (pos_j.begin(),pos_j.end());
	    }
	    
      for (int i=0; i < static_cast<int>(input_x.size());i++)
	    {
	     overall=to_string(input_x[i])+ ","+to_string(input_y[i])+ ","+to_string(input_z[i])+ ","+to_string(input_w[i])+ ","+to_string(input_p[i])+ ","+to_string(input_r[i])+ ","+to_string(input_j1[i])+ ","+to_string(input_j2[i]);
	     outfile<<overall<<endl;
	     row++;
	    }
	    infile.close();
	    outfile.close();
	    }
	    else {cout << "Could not locate file" << endl;}
		
		
		GP1Data gp1Temp;
		GP2Data gp2Temp;
    int xSize = input_x.size();
		for (int i=0; i<xSize;i++)
	    {							
          gp1Temp.X = input_x[i]/1000;
          gp1Temp.Y = input_y[i]/1000;
          gp1Temp.Z = input_z[i]/1000;
          gp1Temp.W = input_w[i]*M_PI/180;
          gp1Temp.P = input_p[i]*M_PI/180;
          gp1Temp.R = input_r[i]*M_PI/180;
          gp2Temp.J1 = input_j1[i]*M_PI/180;
          gp2Temp.J2 = input_j2[i]*M_PI/180;

					mGP1.push_back(gp1Temp);
					mGP2.push_back(gp2Temp);					
        }
    }
};



