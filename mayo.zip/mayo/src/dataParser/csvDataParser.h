#ifndef DATAPARSER_H
#define DATAPARSER_H
#endif // DATAPARSER_H

//#include "dataType.h"
#ifndef DATATYPE_H
#include "src/lib/dataType.h"
#endif // DATATYPE_H

#include "src/lib/rapidcsv.h"


using namespace std;
using namespace rapidcsv;


class CsvDataParser
{
  public:
  vector<GP1Data> mGP1;
  vector<GP2Data> mGP2;

public:
  vector<GP1Data> getGP1()
  {
    return mGP1;
  }

public:
  vector<GP2Data> getGP2()
  {
    return mGP2;
  }

public:	void parseTargetPos(Document doc)
  {
    GP1Data gp1Data;
    GP2Data gp2Data;

    vector<float> posX 	= doc.GetColumn<float>("posX");
    vector<float> posY 	= doc.GetColumn<float>("posY");
    vector<float> posZ 	= doc.GetColumn<float>("posZ");
    vector<float> posW  = doc.GetColumn<float>("posW");
    vector<float> posP  = doc.GetColumn<float>("posP");
    vector<float> posR  = doc.GetColumn<float>("posR");
    vector<float> J1  = doc.GetColumn<float>("J1");
    vector<float> J2  = doc.GetColumn<float>("J2");

    for (size_t i = 0; i < posX.size(); ++i)
    {
      gp1Data.X = posX[i];
      gp1Data.Y = posY[i];
      gp1Data.Z = posZ[i];
      gp1Data.W	= posW[i];
      gp1Data.P	= posP[i];
      gp1Data.R	= posR[i];
      gp2Data.J1 = J1[i];
      gp2Data.J2 = J2[i];

      mGP1.push_back(gp1Data);
      mGP2.push_back(gp2Data);
    }
  }

 };
