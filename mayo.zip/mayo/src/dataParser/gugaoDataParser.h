#include <iostream>
#include <math.h>
#include <cmath>
#include <fstream>
#include <string>
#include <sstream>
#include <typeinfo>
#include <algorithm>
#include <vector>

#ifndef DATATYPE_H
#include "src/lib/dataType.h"
#endif // DATATYPE_H

#ifndef M_PI
#define M_PI (3.14159265358979323846)
#endif

using namespace std;

class GugaoDataParser
{	
	public:
	vector<GP1Data> mGP1;
	vector<GP2Data> mGP2;

  GugaoHeader mGugaoHeader;

  public:
  void parseData (string filename)
	{
      string sLine;
	    ifstream infile;
	    infile.open(filename);
      //ofstream outfile(output_filename);

      if (infile.is_open())
	    {
        while(getline(infile,sLine))
	      {
           //Read SPEED
          if (sLine.compare(0,5,"SPEED")==0)
          {
            mGugaoHeader.vsSpeedHeader.push_back(sLine.substr(int(0),static_cast<int>(sLine.length())));
          }

           if (sLine.compare(0,3,"DYN")==0)
           {
             //Read ACC, DEC, J
             vector<int> backspaces;
             vector<int> equals;
             for (int pos=0; pos < static_cast<int>(sLine.length());pos++)
             {
               if ((sLine[pos]==' ')||(sLine[pos]=='\0'))
                {
                  backspaces.push_back(pos);
                }
               if (sLine[pos]=='=')
               {
                  equals.push_back(pos+1);
               }
             }
            int acc_len = backspaces[1] - equals[0];
            mGugaoHeader.vAcc.push_back(stod(sLine.substr(equals[0],acc_len)));
            int dec_len = backspaces[2] - equals[1];
            mGugaoHeader.vDec.push_back(stod(sLine.substr(equals[1],dec_len)));
            int j_len = backspaces[3] - equals[2];
            mGugaoHeader.vJ.push_back(stod(sLine.substr(equals[2],j_len)));
           }

            if ((sLine.compare(0,4,"MOVJ")==0) || (sLine.compare(0,4,"MOVL")==0))
            {
              //Read pos
               vector<int> posComma;
               vector<int> posDollar;
              //int posAt;
             for (int pos=0; pos < static_cast<int>(sLine.length());pos++)
             {
                /*if (sLine[pos]=='@')
                {
                  posAt = pos;
                }*/
                if (sLine[pos]=='$')
                {
                  posDollar.push_back(pos);
                }
                if (sLine[pos]==',')
                {
                  posComma.push_back(pos);
                }
             }
             mGugaoHeader.vsDataHeader.push_back(sLine.substr(int(0),posComma[3])+',');
             GP1Data gp1Data;
             GP2Data gp2Data;
             gp1Data.X = stod(sLine.substr(posComma[3]+1,posComma[4]-posComma[3]-1));
             gp1Data.Y = stod(sLine.substr(posComma[4]+1,posComma[5]-posComma[4]-1));
             gp1Data.Z = stod(sLine.substr(posComma[5]+1,posComma[6]-posComma[5]-1));
             gp1Data.W = stod(sLine.substr(posComma[6]+1,posComma[7]-posComma[6]-1));
             gp1Data.P = stod(sLine.substr(posComma[7]+1,posComma[8]-posComma[7]-1));
             gp1Data.R = stod(sLine.substr(posComma[8]+1,posComma[9]-posComma[8]-1));
             gp2Data.J1 = stod(sLine.substr(posDollar[1]+1,posComma[22]-posDollar[1]-1));
             gp2Data.J2 = stod(sLine.substr(posComma[22]+1,posComma[23]-posComma[22]-1));
             mGP1.push_back(gp1Data);
             mGP2.push_back(gp2Data);
           }
        }
/*      int row = 0;
        string overall;
        for (int i=0; i < static_cast<int>(input_x.size());i++)
        {
           overall=to_string(input_x[i])+ ","+to_string(input_y[i])+ ","+to_string(input_z[i])+ ","+to_string(input_w[i])+ ","+to_string(input_p[i])+ ","+to_string(input_r[i])+ ","+to_string(input_j1[i])+ ","+to_string(input_j2[i]);
           outfile<<overall<<endl;
           row++;
        }  */

        infile.close();
        //outfile.close();
      }
      else
      {
        cout << "Could not locate file" << endl;
      }

    /*
        GP1Data gp1Temp;
        GP2Data gp2Temp;
        int xSize = input_x.size();
        for (int i=0; i<xSize;i++)
        {
              gp1Temp.X = input_x[i]/1000;
              gp1Temp.Y = input_y[i]/1000;
              gp1Temp.Z = input_z[i]/1000;
              gp1Temp.W = input_w[i]*M_PI/180;
              gp1Temp.P = input_p[i]*M_PI/180;
              gp1Temp.R = input_r[i]*M_PI/180;
              gp2Temp.J1 = input_j1[i]*M_PI/180;
              gp2Temp.J2 = input_j2[i]*M_PI/180;

              mGP1.push_back(gp1Temp);
              mGP2.push_back(gp2Temp);
        }
        */
    }
};



