#ifndef DATATYPE_H
#define DATATYPE_H

#endif // DATATYPE_H

#include <vector>
#include <string>

using namespace std;

class PathConvert{
public:
  vector<GP1Data> mGp1Data;
  vector<GP2Data> mGp2Data;
  vector<GP1Data> mGp1NewPath;
  vector<GP2Data> mGp2NewPath;

public:
  void pathExtract(vector<GP1Data> gp1, vector<GP2Data> gp2){
    if(gp1.size()<2)
    {
      mGp1Data.push_back(gp1[0]);
      mGp2Data.push_back(gp2[0]);
    }
    else
    {
      GP1Data gpData;
      for(int i=0; i<(gp1.size()-1); i++)
      {
         gpData.X = gp1[i+1].X - gp1[i].X;
         gpData.Y = gp1[i+1].Y - gp1[i].Y;
         gpData.Z = gp1[i+1].Z - gp1[i].Z;
         gpData.W = gp1[i+1].W - gp1[i].W;
         gpData.P = gp1[i+1].P - gp1[i].P;
         gpData.R = gp1[i+1].R - gp1[i].R;
         mGp1Data.push_back(gpData);
      }

      GP2Data gp2Data;
      for(int i=0; i<(gp2.size()-1); i++)
      {
         gp2Data.J1 = gp2[i+1].J1 - gp2[i].J1;
         gp2Data.J2 = gp2[i+1].J2 - gp2[i].J2;
         mGp2Data.push_back(gp2Data);
      }
    }
  }

  void convert(vector<GP1Data> newOri, vector<GP2Data> newOri2)
  {
    GP1Data gpData;
    int newOriSize = mGp1Data.size();
    for(int i=0; i<(newOriSize-1); i++)
    {
       gpData.X = newOri[0].X + mGp1Data[i].X;
       gpData.Y = newOri[0].Y + mGp1Data[i].Y;
       gpData.Z = newOri[0].Z + mGp1Data[i].Z;
       gpData.W = newOri[0].W + mGp1Data[i].W;
       gpData.P = newOri[0].P + mGp1Data[i].P;
       gpData.R = newOri[0].R + mGp1Data[i].R;
       mGp1NewPath.push_back(gpData);
    }
    gpData.X = newOri[newOriSize-1].X;
    gpData.Y = newOri[newOriSize-1].Y;
    gpData.Z = newOri[newOriSize-1].Z;
    gpData.W = newOri[newOriSize-1].W;
    gpData.P = newOri[newOriSize-1].P;
    gpData.R = newOri[newOriSize-1].R;
    mGp1NewPath.push_back(gpData);

    GP2Data gp2Data;
    int newOri2Size = mGp2Data.size();
    for(int i=0; i<(newOri2Size-1); i++)
    {
       gp2Data.J1 = newOri2[0].J1 + mGp2Data[i].J1;
       gp2Data.J2 = newOri2[0].J2 + mGp2Data[i].J2;
       mGp2NewPath.push_back(gp2Data);
    }
    gp2Data.J1 = newOri2[newOri2Size-1].J1;
    gp2Data.J2 = newOri2[newOri2Size-1].J2;
    mGp2NewPath.push_back(gp2Data);
   }

};
