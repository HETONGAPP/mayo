#ifndef DATATYPE_H
#define DATATYPE_H

#endif // DATATYPE_H

#include <vector>
#include <string>

using namespace std;

struct Pose{
  double PosX;
  double PosY;
  double PosZ;
  double OriX;
  double OriY;
  double OriZ;
  double OriW;
};

struct GP1Data{
  double X;
  double Y;
  double Z;
  double W;
  double P;
  double R;
};

struct GP2Data{
  double J1;
  double J2;
};

struct GugaoHeader{
  vector<int> vAcc;
  vector<int> vDec;
  vector<int> vJ;
  vector<string> vsDataHeader;
  vector<string> vsSpeedHeader;
};
